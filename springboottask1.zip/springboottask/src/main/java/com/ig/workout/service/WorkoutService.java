package com.ig.workout.service;


import com.ig.workout.entity.WorkoutEntity;
import com.ig.workout.model.Workout;
import com.ig.workout.repository.WorkoutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class WorkoutService {

    @Autowired
    private WorkoutRepository workoutRepository;

    public Workout addWorkout(Workout workout) {
        WorkoutEntity entity = new WorkoutEntity();
        entity.setTitle(workout.getTitle());
        entity.setDuration(workout.getDuration());
        entity.setCaloriesBurnt(workout.getCaloriesBurnt());
        entity.setCategory(workout.getCategory());
        
        workoutRepository.save(entity);
        workout.setTitle(entity.getTitle());
        return workout;
    }

    public List<Workout> getAllWorkouts() {
        return workoutRepository.findAll().stream().map(entity -> 
            new Workout(entity.getTitle(), entity.getDuration(), entity.getCaloriesBurnt(), entity.getCategory())
        ).collect(Collectors.toList());
    }
}
