package week1solution;

import week1solution.LowBalanceException;
import week1solution.InvalidAmountException;

public class Account {
    private Integer accNumber;
    private String custName;
    private AccountType type;
    private Float balance;

    public enum AccountType {
        SAVINGS, CURRENT
    }

    public Account(Integer accNumber, String custName, AccountType type, Float balance) throws InvalidAmountException, LowBalanceException {
        this.accNumber = accNumber;
        this.custName = custName;
        this.type = type;
   
        if (balance < 0) {
            throw new InvalidAmountException("Initial balance cannot be negative.");
        }
        
        if (type == AccountType.SAVINGS && balance < 1000) {
            throw new LowBalanceException("Minimum balance of 1000 required for savings account.");
        } else if (type == AccountType.CURRENT && balance < 5000) {
            throw new LowBalanceException("Minimum balance of 5000 required for current account.");
        }
        
        this.balance = balance;
    }

    public Integer getAccNumber() {
        return accNumber;
    }

    public String getCustName() {
        return custName;
    }

    public AccountType getType() {
        return type;
    }

    public Float getBalance() {
        return balance;
    }

    public void setBalance(Float balance) {
        this.balance = balance;
    }
}
