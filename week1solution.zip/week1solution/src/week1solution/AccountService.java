package week1solution;

import week1solution.Account;
import week1solution.AccountNotFoundException;
import week1solution.InvalidAmountException;
import week1solution.InsufficientFundsException;

import java.util.ArrayList;
import java.util.List;

public class AccountService {

    private List<Account> accountList = new ArrayList<>();

    public AccountService() {
       
        try {
            accountList.add(new Account(101, "Alice", Account.AccountType.SAVINGS, 2000f));
            accountList.add(new Account(102, "Bob", Account.AccountType.CURRENT, 6000f));
            accountList.add(new Account(103, "Charlie", Account.AccountType.SAVINGS, 5000f));
            accountList.add(new Account(104, "Dave", Account.AccountType.CURRENT, 10000f));
            accountList.add(new Account(105, "Eve", Account.AccountType.SAVINGS, 1200f));
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public boolean isValidAccount(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                return true;
            }
        }
        throw new AccountNotFoundException("Account with number " + accNumber + " not found.");
    }

    public void deposit(int accNumber, float amt) throws InvalidAmountException {
        if (amt < 0) {
            throw new InvalidAmountException("Deposit amount cannot be negative.");
        }

        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                account.setBalance(account.getBalance() + amt);
                return;
            }
        }
    }

    public void withdraw(int accNumber, float amt) throws AccountNotFoundException, InvalidAmountException, InsufficientFundsException, LowBalanceException {
        if (amt < 500) {
            throw new InvalidAmountException("Minimum withdrawal amount is 500.");
        }

        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                if (account.getType() == Account.AccountType.SAVINGS && account.getBalance() - amt < 1000) {
                    throw new InsufficientFundsException("Insufficient funds in savings account.");
                } else if (account.getType() == Account.AccountType.CURRENT && account.getBalance() - amt < 5000) {
                    throw new InsufficientFundsException("Insufficient funds in current account.");
                }

                account.setBalance(account.getBalance() - amt);
                return;
            }
        }
        throw new AccountNotFoundException("Account not found.");
    }

    public float getBalance(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                return account.getBalance();
            }
        }
        throw new AccountNotFoundException("Account not found.");
    }
}
