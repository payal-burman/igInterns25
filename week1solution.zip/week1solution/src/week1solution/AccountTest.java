package week1solution;

import week1solution.InsufficientFundsException;
import week1solution.LowBalanceException;
import week1solution.InvalidAmountException;
import week1solution.AccountNotFoundException;


public class AccountTest {
    public static void main(String[] args) {
        AccountService accountService = new AccountService();
        
        try {
       
            int accNumber = 101;
            System.out.println("Initial balance of account " + accNumber + ": " + accountService.getBalance(accNumber));

            accountService.deposit(accNumber, 1500f);
            System.out.println("After depositing 1500, balance is: " + accountService.getBalance(accNumber));

            accountService.withdraw(accNumber, 500f);
            System.out.println("After withdrawing 500, balance is: " + accountService.getBalance(accNumber));

            accountService.withdraw(accNumber, 600f);
            System.out.println("After withdrawing 600, balance is: " + accountService.getBalance(accNumber));

        } catch (AccountNotFoundException | InvalidAmountException | InsufficientFundsException | LowBalanceException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
