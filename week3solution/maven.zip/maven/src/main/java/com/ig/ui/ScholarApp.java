package com.ig.ui;

import com.ig.model.Scholar;
import com.ig.service.ScholarService;
import com.ig.exception.ScholarNotFoundException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class ScholarApp {
    public static void main(String[] args) {
        ScholarService scholarService = new ScholarService();
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Adding Scholars...");
            
            scholarService.addScholar(new Scholar(3, "Alice Johnson", "alice@example.com", "5551234567"));
            scholarService.addScholar(new Scholar(4, "Bob Brown", "bob@example.com", "4449876543"));
            scholarService.addScholar(new Scholar(5, "Charlie Davis", "charlie@example.com", "3334567890"));
            

            System.out.println("Listing All Scholars:");
            List<Scholar> scholars = scholarService.getAllScholars();
            scholars.forEach(System.out::println);

            System.out.println("Enter Scholar ID to retrieve:");
            int id = scanner.nextInt();
            System.out.println(scholarService.getScholarById(id));

            System.out.println("Enter Scholar ID to update email:");
            id = scanner.nextInt();
            System.out.println("Enter new email:");
            String newEmail = scanner.next();
            scholarService.updateScholarEmail(id, newEmail);
            System.out.println("Email updated successfully!");

            System.out.println("Enter Scholar ID to delete:");
            id = scanner.nextInt();
            scholarService.deleteScholarById(id);
            System.out.println("Scholar deleted successfully!");

        } catch (SQLException | ScholarNotFoundException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}