package com.ig.dao;

import com.ig.model.Scholar;
import com.ig.exception.ScholarNotFoundException;
import com.ig.util.DbUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ScholarDao {
    private Connection connection;

    public ScholarDao() {
        this.connection = DbUtil.getConnection();
    }

    public void addScholar(Scholar scholar) throws SQLException {
        String sql = "INSERT INTO Scholar (Rollno, Name, Email, Mobile) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, scholar.getScholarId());
            ps.setString(2, scholar.getName());
            ps.setString(3, scholar.getEmail());
            ps.setString(4, scholar.getMobile());
            ps.executeUpdate();
        }
    }

    public Scholar getScholarById(int scholarId) throws SQLException, ScholarNotFoundException {
        String sql = "SELECT * FROM Scholar WHERE Rollno = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, scholarId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Scholar(rs.getInt("Rollno"), rs.getString("Name"), rs.getString("Email"), rs.getString("Mobile"));
            } else {
                throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
            }
        }
    }

    public List<Scholar> getAllScholars() throws SQLException {
        List<Scholar> scholars = new ArrayList<>();
        String sql = "SELECT * FROM Scholar";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                scholars.add(new Scholar(rs.getInt("Rollno"), rs.getString("Name"), rs.getString("Email"), rs.getString("Mobile")));
            }
        }
        return scholars;
    }

    public void updateScholarEmail(int scholarId, String newEmail) throws SQLException, ScholarNotFoundException {
        String sql = "UPDATE Scholar SET Email = ? WHERE Rollno = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, newEmail);
            ps.setInt(2, scholarId);
            int rowsUpdated = ps.executeUpdate();
            if (rowsUpdated == 0) {
                throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
            }
        }
    }

    public void deleteScholarById(int scholarId) throws SQLException, ScholarNotFoundException {
        String sql = "DELETE FROM Scholar WHERE Rollno = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, scholarId);
            int rowsDeleted = ps.executeUpdate();
            if (rowsDeleted == 0) {
                throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
            }
        }
    }
}